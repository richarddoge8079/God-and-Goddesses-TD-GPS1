﻿using UnityEngine;
using System.Collections;

public class SpawnEnemy : MonoBehaviour {

	public GameObject[] wayPoints;
	public GameObject testEnemyPrefab;

	// Use this for initialization
	void Start () {
		Instantiate (testEnemyPrefab).GetComponent<EnemyMovement> ().wayPoints = wayPoints;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
