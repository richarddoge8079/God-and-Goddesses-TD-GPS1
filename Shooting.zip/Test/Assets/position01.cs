﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;

public class position01 : MonoBehaviour {

	float _radius = 0.5f ;
	Vector3 _prevPos , _dirV;
	Transform _transform ;
	// Use this for initialization
	void Start () {
		_transform = transform;
		_prevPos = _transform.position;
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (_transform.position == _prevPos)
			return; 

		_dirV = _transform.position - _prevPos;
		RaycastHit2D hit = Physics2D.Raycast (_transform.position, _dirV, _radius);

		if (hit.collider != null) {
			if (hit.normal.x != 0f) {
				if (hit.normal.x > 0f)
					Debug.Log ("Left Side");
				else
					Debug.Log ("Right Side");
			} else if (hit.normal.y != 0f) {
				if (hit.normal.y < 0f)
					Debug.Log ("top side");
				else
					Debug.Log ("Bottom side");
			}
		}

		_prevPos = _transform.position; 

	
	}
}
